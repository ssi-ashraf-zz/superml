library(testthat)
library(superml)

test_check("superml")
