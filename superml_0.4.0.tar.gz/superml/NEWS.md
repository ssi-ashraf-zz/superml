# superml 0.4.0

* Fixed svm error. Replaced liquidSVM with e1071 R package.

# superml 0.3.0

* Moved some imports to suggests

# superml 0.2.0

* Added new trainers: SVM, NaiveBayes
* Renamed gridsearch, randomsearch trainers to CV
* Fixed documentation

# superml 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* Fixed travis-ci integration    

